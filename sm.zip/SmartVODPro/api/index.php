<?php
error_reporting(0);
$db = new SQLite3('./.db.db');
$res = $db->query('SELECT * FROM dns'); 
$rows = array();
$rowsn = array();
$json_response = array(); 

function part1($plaintext) {
    if ($plaintext == null) {
        return null;
    }

	$f2hg79IE6Y1A6yJzVe2d = 'UnNLaXZEdW9lUmdIeFMxOA==';
    $zMjVfb7PNtffh4E62MRK = base64_decode($f2hg79IE6Y1A6yJzVe2d, true);
    $salt = substr($zMjVfb7PNtffh4E62MRK, 0, 16); 
	$iv = 'tbDX3QvEUZW6gS5M';

    try {
        $cipherMethod = "AES-128-CBC";
        $encrypted = openssl_encrypt($plaintext, $cipherMethod, $salt, OPENSSL_RAW_DATA, $iv);
        return base64_encode($encrypted);
    } catch (Exception $e) {
        echo $e->getMessage();
        return null;
    }
}

function part2($plaintext) {
    if ($plaintext == null) {
        return null;
    }

	$f2hg79IE6Y1A6yJzVe2d = 'ODFTeEhnUmVvdUR2aUtzUg==';
    $zMjVfb7PNtffh4E62MRK = base64_decode($f2hg79IE6Y1A6yJzVe2d, true);
    $salt = substr($zMjVfb7PNtffh4E62MRK, 0, 16); 
	$iv = 'tbDX3QvEUZW6gS5M';

    try {
        $cipherMethod = "AES-128-CBC";
        $encrypted = openssl_encrypt($plaintext, $cipherMethod, $salt, OPENSSL_RAW_DATA, $iv);
        return base64_encode($encrypted);
    } catch (Exception $e) {
        echo $e->getMessage();
        return null;
    }
}

    
while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
	$row_array['name'] = $row['title']; 
	$row_array['url'] = $row['url']; 
	array_push($json_response,$row_array);  
}



header('Content-type: application/json; charset=UTF-8');

//$final = json_encode($json_response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
//$output_json = '{"portals":' . $final . '}';

$arrayVar = [
    "portals" => $json_response,
    "key" => "",
    "message_one" => "Welcome",
    "message_two" =>
        "Please Select your service and enter username/password to login",
    "message_three" => "Enjoy!",
];

$output_json = json_encode($arrayVar);


$first22 = substr($output_json, 0, 22);
$rest = substr($output_json, 22);

$encrypt_part1=part1($first22);
$encrypt_part2=part2($rest);
$length = strlen($encrypt_part1);

$fullcode = $encrypt_part1 . $encrypt_part2 . '!' . $length ;

$fullcode_output = base64_encode($fullcode);

$api = '{"data": "'.$fullcode_output.'"}';
echo $api;
?>