<?php
/*
 * @ https://EasyToYou.eu - IonCube v11 Decoder Online
 * @ PHP 7.2
 * @ Decoder version: 1.0.4
 * @ Release: 01/09/2021
 */

$panel_name = "HC All in One";
$show_toa = "yes";
$show_ip = "yes";

?>